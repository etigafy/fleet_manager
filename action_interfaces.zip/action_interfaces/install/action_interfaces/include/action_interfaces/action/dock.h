// generated from rosidl_generator_c/resource/idl.h.em
// with input from action_interfaces:action/Dock.idl
// generated code does not contain a copyright notice

#ifndef ACTION_INTERFACES__ACTION__DOCK_H_
#define ACTION_INTERFACES__ACTION__DOCK_H_

#include "action_interfaces/action/detail/dock__struct.h"
#include "action_interfaces/action/detail/dock__functions.h"
#include "action_interfaces/action/detail/dock__type_support.h"

#endif  // ACTION_INTERFACES__ACTION__DOCK_H_

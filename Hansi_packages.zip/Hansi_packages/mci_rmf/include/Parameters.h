#pragma once

class Parameters
{
public:
    const static float CHARGING_THRESHOLD = 0.15;
};
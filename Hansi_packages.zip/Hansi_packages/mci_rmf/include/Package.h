#pragma once


// ------------------------------------------------------------------------------------------------
class Package
{
public:
    Package(/* args */);
    ~Package();


private:
    /* data */

};